#!/bin/ash
mv /tmp/nginx/data/etc /etc
mv /tmp/nginx/data/lib /lib
mv /tmp/nginx/data/usr /usr
mv /tmp/nginx/data/usr /usr